import csv
from claseMateria import Materia

class manejaMateria:
    __lista=[]
    def __init__(self):
        self.__lista=[]
    def cargarArchi(self):
        archivo=open('materiasAprobadas.csv')
        reader=csv.reader(archivo,delimiter=';')
        for fila in reader:
            self.agregar(fila[0],fila[1],fila[2],fila[3],fila[4])
    def agregar(self,dni,nombre,nota,fecha,aprobacion):
        self.__lista.append(Materia(dni,nombre,nota,fecha,aprobacion))
    def informa(self):
        dniAlumno=(input("Ingrese el DNI del alumno "))
        acum=int("0")
        con=int("0")    #cuenta notas con aplazos
        prom=int("0")
        for i in self.__lista:
            if i.getDNI() == dniAlumno:
                acum +=i.getNota()
                con+=1
                print("Esto es acum {}".format(acum))
                print("Esto es contador: {}".format(con))
            
                # if self.__lista.getNota()<=10:
                #     acum+=self.__lista.getNota()
                #     con+=1
                #     prom= acum/con
                #     print("El alumno {}, tiene un promedio (con aplazos) de {} ",dniAlumno, prom)
                # elif self.__lista.getNota()>=4:
                #     acum+=self.__lista.getNota()
                #     con+=1
                #     prom=acum/con
        prom=acum/con
        print("El alumno {}, tiene un promedio  de {} ".format(dniAlumno, prom))
        return
    def mostrar(self):
        for i in range(len(self.__lista)):
            print(self.__lista[i])
    
            
            

        
            
            
            
            
            
        

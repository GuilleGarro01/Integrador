from claseMateria import Materia
from claseAlumno import Alumno
from manejadorAlu import manejAlum
from manejadorMateria import manejaMateria
import numpy as np
import csv
if __name__== '__main__':
    unAlumno=manejAlum(5)
    unaMateria=manejaMateria()
    unaMateria.cargarArchi()
    #unAlumno.AbrirArchi()
    unaMateria.mostrar()
    print ("--------MENU--------")
    print("1.VER PROMEDIO DE UN ALUMNO ")
    print("2.VER APROBADOS PROMOCIONALES ")
    print("3.VER LISTADO DE ALUMNOS ")
    opc=int(input("Ingrese una opcion "))
    
    while opc !=4:
        if opc==1:
           unaMateria.informa()
        # elif opc==2:
        #     unaMateria.inforPromo()
        print ("--------MENU--------")
        print("1.VER PROMEDIO DE UN ALUMNO ")
        print("2.VER APROBADOS PROMOCIONALES ")
        print("3.VER LISTADO DE ALUMNOS ")
        opc=int(input("Ingrese una opcion "))
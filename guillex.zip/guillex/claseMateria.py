class Materia:
    __dni=""
    __nombreMateria=""
    __fecha=""
    __nota=""
    __aprobacion=""
    def __init__(self,dni="",nombreMateria="",fecha="",nota="",aprobacion=""):
        self.__dni=dni
        self.__nombreMateria=nombreMateria
        self.__fecha=fecha
        self.__nota=int(nota)
        self.__aprobacion=aprobacion
    def __str__(self):
        return (f"{self.__dni}{self.__nombreMateria}{self.__fecha}{self.__nota}{self.__aprobacion}")
    def getDNI(self):
        return self.__dni 
    def getNM (self):
        return self.__nombreMateria
    def getF(self):
        return self.__fecha
    def getNota (self):
        return self.__nota
    def getApro(self):
        return self.__aprobacion
    # def verifdni(self,dni):
    #     if self.__dni == dni:
    #         return True
    